
import React, { useState } from 'react';
import { Link } from 'react-router';
import { ChevronLeft, Truck, Clock, ShieldCheck, ArrowRight, CheckCircle2, Lock } from 'lucide-react';
import { CartItem, Order } from '../types';
import { backendService } from '../services/backendService';

interface CheckoutProps {
  cart: CartItem[];
  onOrderComplete: (order: Order) => void;
}

const ZapIcon = ({ size, className }: { size: number, className?: string }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
  </svg>
);

const DELIVERY_OPTIONS = [
  { id: 'standard', name: 'Standard Delivery', cost: 0, time: '3-5 business days', icon: <Truck size={20} /> },
  { id: 'express', name: 'Express Delivery', cost: 15, time: '1-2 business days', icon: <Clock size={20} /> },
  { id: 'nextday', name: 'Next-Day Delivery', cost: 30, time: 'Next business day', icon: <ZapIcon size={20} className="text-amber-500" /> },
];

const Checkout: React.FC<CheckoutProps> = ({ cart, onOrderComplete }) => {
  const [selectedDelivery, setSelectedDelivery] = useState(DELIVERY_OPTIONS[0]);
  const [isOrdered, setIsOrdered] = useState(false);
  const [lastOrder, setLastOrder] = useState<Order | null>(null);

  const subtotal = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const total = subtotal + selectedDelivery.cost;

  // Added async and await to correctly handle the Promise returned by backendService.createOrder
  const handlePlaceOrder = async () => {
    if (cart.length === 0) return;
    
    // Fixed: await the promise to get the actual Order object
    const newOrder = await backendService.createOrder({
      total: total,
      items: cart,
      deliveryMethod: selectedDelivery.name,
    });

    setLastOrder(newOrder);
    setIsOrdered(true);
    onOrderComplete(newOrder);
  };

  if (isOrdered && lastOrder) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-24 text-center space-y-8 animate-in fade-in slide-in-from-bottom-10 duration-700">
        <div className="flex justify-center">
          <div className="bg-emerald-100 text-emerald-600 p-8 rounded-full shadow-inner">
            <CheckCircle2 size={80} />
          </div>
        </div>
        <div className="space-y-4">
          <h1 className="text-5xl font-display font-bold text-slate-900">Merci!</h1>
          <p className="text-slate-500 text-lg max-w-md mx-auto">
            Your order <span className="font-bold text-slate-900">#{lastOrder.id}</span> is confirmed. 
            Estimated delivery via {selectedDelivery.name} by {selectedDelivery.time}.
          </p>
        </div>
        <div className="flex justify-center space-x-4">
          <Link to="/" className="inline-block bg-slate-900 text-white px-10 py-5 rounded-full font-bold hover:bg-slate-800 transition-all shadow-xl shadow-slate-200">
            Return to Store
          </Link>
          <Link to="/account" className="px-10 py-5 bg-white border border-slate-200 rounded-full font-bold hover:bg-slate-50 transition-all">
            View My Orders
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <Link to="/" className="inline-flex items-center text-sm font-bold text-slate-400 hover:text-slate-900 mb-8 space-x-2 transition-colors">
        <ChevronLeft size={16} />
        <span className="uppercase tracking-widest">Store</span>
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
        <div className="lg:col-span-7 space-y-12">
          <div className="flex items-center space-x-4 pb-4 border-b border-slate-100">
            <div className="h-10 w-10 bg-slate-900 text-white rounded-full flex items-center justify-center font-bold">1</div>
            <h2 className="text-2xl font-display font-bold text-slate-900">Shipping Strategy</h2>
          </div>
          
          <div className="grid grid-cols-1 gap-4">
            {DELIVERY_OPTIONS.map((option) => (
              <button
                key={option.id}
                onClick={() => setSelectedDelivery(option)}
                className={`group flex items-center justify-between p-6 rounded-3xl border-2 transition-all text-left ${
                  selectedDelivery.id === option.id 
                    ? 'border-slate-900 bg-slate-50 shadow-xl shadow-slate-200/20' 
                    : 'border-slate-100 hover:border-slate-200 bg-white'
                }`}
              >
                <div className="flex items-center space-x-5">
                  <div className={`p-4 rounded-2xl transition-colors ${
                    selectedDelivery.id === option.id ? 'bg-slate-900 text-white' : 'bg-slate-50 text-slate-400'
                  }`}>
                    {option.icon}
                  </div>
                  <div>
                    <p className="font-bold text-slate-900 text-lg">{option.name}</p>
                    <p className="text-sm text-slate-500">{option.time}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-slate-900 text-lg">
                    {option.cost === 0 ? 'FREE' : `$${option.cost.toFixed(2)}`}
                  </p>
                </div>
              </button>
            ))}
          </div>

          <div className="flex items-center space-x-4 pb-4 border-b border-slate-100 mt-12">
            <div className="h-10 w-10 bg-slate-900 text-white rounded-full flex items-center justify-center font-bold">2</div>
            <h2 className="text-2xl font-display font-bold text-slate-900">Destination Details</h2>
          </div>
          
          <div className="grid grid-cols-2 gap-6">
            <input type="text" placeholder="First Name" className="col-span-1 p-5 rounded-2xl bg-slate-50 border-none focus:ring-2 focus:ring-slate-900" />
            <input type="text" placeholder="Last Name" className="col-span-1 p-5 rounded-2xl bg-slate-50 border-none focus:ring-2 focus:ring-slate-900" />
            <input type="text" placeholder="Address" className="col-span-2 p-5 rounded-2xl bg-slate-50 border-none focus:ring-2 focus:ring-slate-900" />
            <input type="text" placeholder="City" className="col-span-1 p-5 rounded-2xl bg-slate-50 border-none focus:ring-2 focus:ring-slate-900" />
            <input type="text" placeholder="ZIP" className="col-span-1 p-5 rounded-2xl bg-slate-50 border-none focus:ring-2 focus:ring-slate-900" />
          </div>
        </div>

        <aside className="lg:col-span-5">
          <div className="bg-slate-50 p-10 rounded-[3rem] sticky top-32 space-y-10 border border-slate-100 shadow-sm">
            <h2 className="text-2xl font-display font-bold text-slate-900">Your Summary</h2>

            <div className="space-y-6 max-h-[30vh] overflow-y-auto pr-2 custom-scrollbar">
              {cart.map((item) => (
                <div key={item.id} className="flex justify-between items-center group">
                  <div className="flex items-center space-x-4">
                    <div className="h-16 w-16 bg-white rounded-xl overflow-hidden shadow-sm">
                      <img src={item.image} alt={item.name} className="h-full w-full object-cover" />
                    </div>
                    <div>
                      <p className="font-bold text-slate-900 text-sm">{item.name}</p>
                      <p className="text-xs text-slate-400 font-medium">Qty: {item.quantity}</p>
                    </div>
                  </div>
                  <p className="font-bold text-slate-900">${(item.price * item.quantity).toFixed(2)}</p>
                </div>
              ))}
            </div>

            <div className="space-y-4 pt-8 border-t border-slate-200">
              <div className="flex justify-between text-slate-500 font-medium">
                <span>Subtotal</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-500 font-medium">
                <span>Delivery</span>
                <span className={selectedDelivery.cost === 0 ? 'text-emerald-600 font-bold' : ''}>
                  {selectedDelivery.cost === 0 ? 'FREE' : `$${selectedDelivery.cost.toFixed(2)}`}
                </span>
              </div>
              <div className="flex justify-between text-2xl font-bold text-slate-900 pt-6 border-t border-slate-200">
                <span>Total</span>
                <span>${total.toFixed(2)}</span>
              </div>
            </div>

            <button 
              onClick={handlePlaceOrder}
              disabled={cart.length === 0}
              className="w-full bg-slate-900 text-white py-6 rounded-[2rem] font-bold shadow-2xl hover:bg-slate-800 transition-all active:scale-95 disabled:opacity-50 flex items-center justify-center space-x-3"
            >
              <span>Complete Order</span>
              <ArrowRight size={20} />
            </button>
            
            <div className="flex items-center justify-center space-x-2 text-slate-400 text-[10px] font-bold uppercase tracking-[0.2em]">
              <Lock size={12} />
              <span>Secure Lumière Gateway</span>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
};

export default Checkout;
