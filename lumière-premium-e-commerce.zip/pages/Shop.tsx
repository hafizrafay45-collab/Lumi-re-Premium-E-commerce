
import React, { useState, useMemo } from 'react';
// Changed import source to 'react-router' to resolve exported member errors.
import { useSearchParams } from 'react-router';
import { SlidersHorizontal, ChevronDown } from 'lucide-react';
import { PRODUCTS, CATEGORIES } from '../constants';
import ProductCard from '../components/ProductCard';
import { Product } from '../types';

interface ShopProps {
  onAddToCart: (p: Product) => void;
}

const Shop: React.FC<ShopProps> = ({ onAddToCart }) => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [sortBy, setSortBy] = useState('Featured');
  
  const currentCategory = searchParams.get('category') || 'All';

  const filteredProducts = useMemo(() => {
    let result = [...PRODUCTS];
    if (currentCategory !== 'All') {
      result = result.filter(p => p.category === currentCategory);
    }
    
    switch (sortBy) {
      case 'Price: Low to High':
        result.sort((a, b) => a.price - b.price);
        break;
      case 'Price: High to Low':
        result.sort((a, b) => b.price - a.price);
        break;
      case 'Top Rated':
        result.sort((a, b) => b.rating - a.rating);
        break;
      default:
        break;
    }
    return result;
  }, [currentCategory, sortBy]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-12 gap-8">
        <h1 className="text-4xl font-display font-bold text-slate-900">
          {currentCategory} Collections
        </h1>
        
        <div className="flex items-center space-x-4 w-full md:w-auto overflow-x-auto pb-4 md:pb-0 scrollbar-hide">
          {CATEGORIES.map(cat => (
            <button
              key={cat}
              onClick={() => setSearchParams(cat === 'All' ? {} : { category: cat })}
              className={`px-6 py-2 rounded-full whitespace-nowrap text-sm font-semibold transition-all ${
                currentCategory === cat 
                ? 'bg-slate-900 text-white shadow-lg' 
                : 'bg-white text-slate-500 border border-slate-200 hover:border-slate-900'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-12">
        {/* Filters Sidebar - Simplified */}
        <aside className="lg:w-64 space-y-8 hidden lg:block">
          <div>
            <h4 className="text-xs font-bold uppercase tracking-widest text-slate-400 mb-4">Sort By</h4>
            <select 
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="w-full bg-slate-50 border-none rounded-xl px-4 py-3 text-sm font-medium focus:ring-2 focus:ring-slate-900"
            >
              <option>Featured</option>
              <option>Price: Low to High</option>
              <option>Price: High to Low</option>
              <option>Top Rated</option>
            </select>
          </div>

          <div>
            <h4 className="text-xs font-bold uppercase tracking-widest text-slate-400 mb-4">Price Range</h4>
            <div className="space-y-4">
              <input type="range" className="w-full accent-slate-900" min="0" max="1000" />
              <div className="flex justify-between text-xs font-bold text-slate-600">
                <span>$0</span>
                <span>$1000</span>
              </div>
            </div>
          </div>

          <div>
            <h4 className="text-xs font-bold uppercase tracking-widest text-slate-400 mb-4">Availability</h4>
            <div className="space-y-3">
              <label className="flex items-center space-x-3 cursor-pointer">
                <input type="checkbox" className="rounded text-slate-900 focus:ring-slate-900" />
                <span className="text-sm font-medium text-slate-700">In Stock</span>
              </label>
              <label className="flex items-center space-x-3 cursor-pointer">
                <input type="checkbox" className="rounded text-slate-900 focus:ring-slate-900" />
                <span className="text-sm font-medium text-slate-700">Pre-order</span>
              </label>
            </div>
          </div>
        </aside>

        {/* Mobile Filter Toggle */}
        <div className="lg:hidden flex items-center justify-between mb-8 p-4 bg-slate-50 rounded-2xl">
          <button className="flex items-center space-x-2 font-bold text-slate-900">
            <SlidersHorizontal size={20} />
            <span>Filters</span>
          </button>
          <div className="flex items-center space-x-1 font-bold text-slate-900">
            <span>{sortBy}</span>
            <ChevronDown size={16} />
          </div>
        </div>

        {/* Product Grid */}
        <div className="flex-1">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProducts.map(product => (
              <ProductCard key={product.id} product={product} onAddToCart={onAddToCart} />
            ))}
          </div>
          
          {filteredProducts.length === 0 && (
            <div className="text-center py-24 bg-slate-50 rounded-3xl">
              <p className="text-slate-500 font-medium">No products found matching your criteria.</p>
              <button 
                onClick={() => {setSearchParams({}); setSortBy('Featured');}}
                className="mt-4 text-slate-900 font-bold underline underline-offset-4"
              >
                Clear all filters
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Shop;
