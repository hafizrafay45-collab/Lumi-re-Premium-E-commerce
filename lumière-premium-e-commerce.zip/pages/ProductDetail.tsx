
import React, { useState } from 'react';
// Changed import source to 'react-router' to resolve exported member errors.
import { useParams, Link } from 'react-router';
import { Star, Truck, ShieldCheck, Heart, Share2, Plus, Minus, Check } from 'lucide-react';
import { PRODUCTS } from '../constants';
import { Product } from '../types';

interface ProductDetailProps {
  onAddToCart: (p: Product, qty: number, color?: string, size?: string) => void;
}

const ProductDetail: React.FC<ProductDetailProps> = ({ onAddToCart }) => {
  const { id } = useParams();
  const product = PRODUCTS.find(p => p.id === id);
  const [quantity, setQuantity] = useState(1);
  const [selectedColor, setSelectedColor] = useState(product?.colors?.[0]);
  const [selectedSize, setSelectedSize] = useState(product?.sizes?.[0]);
  const [activeTab, setActiveTab] = useState('description');

  if (!product) return (
    <div className="max-w-7xl mx-auto px-4 py-24 text-center">
      <h2 className="text-2xl font-bold mb-4">Product Not Found</h2>
      <Link to="/shop" className="text-slate-900 underline">Back to shop</Link>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <nav className="flex text-xs font-bold uppercase tracking-widest text-slate-400 mb-8 space-x-2">
        <Link to="/" className="hover:text-slate-900">Home</Link>
        <span>/</span>
        <Link to={`/shop?category=${product.category}`} className="hover:text-slate-900">{product.category}</Link>
        <span>/</span>
        <span className="text-slate-900">{product.name}</span>
      </nav>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
        {/* Product Images */}
        <div className="space-y-4">
          <div className="aspect-[4/5] rounded-3xl bg-slate-100 overflow-hidden">
            <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
          </div>
          <div className="grid grid-cols-4 gap-4">
            {[1, 2, 3, 4].map(i => (
              <div key={i} className="aspect-square rounded-xl bg-slate-100 overflow-hidden cursor-pointer hover:opacity-75 transition-opacity">
                <img src={product.image} className="w-full h-full object-cover" />
              </div>
            ))}
          </div>
        </div>

        {/* Product Info */}
        <div className="flex flex-col">
          <div className="flex justify-between items-start">
            <h1 className="text-4xl md:text-5xl font-display font-bold text-slate-900 mb-4">{product.name}</h1>
            <div className="flex space-x-2">
              <button className="p-3 bg-slate-50 rounded-full hover:bg-slate-100"><Heart size={20} /></button>
              <button className="p-3 bg-slate-50 rounded-full hover:bg-slate-100"><Share2 size={20} /></button>
            </div>
          </div>

          <div className="flex items-center space-x-4 mb-8">
            <div className="flex text-amber-400">
              {[...Array(5)].map((_, i) => (
                <Star key={i} size={18} fill={i < Math.floor(product.rating) ? "currentColor" : "none"} />
              ))}
            </div>
            <span className="text-sm font-bold text-slate-900">{product.rating}</span>
            <span className="text-slate-300">|</span>
            <span className="text-sm text-slate-500">{product.reviews} Customer Reviews</span>
          </div>

          <div className="text-3xl font-bold text-slate-900 mb-8">${product.price.toFixed(2)}</div>

          <p className="text-slate-600 mb-8 leading-relaxed">
            {product.description}
          </p>

          {/* Variants */}
          {product.colors && (
            <div className="mb-8">
              <h4 className="text-xs font-bold uppercase tracking-widest text-slate-400 mb-4">Select Color</h4>
              <div className="flex space-x-4">
                {product.colors.map(color => (
                  <button
                    key={color}
                    onClick={() => setSelectedColor(color)}
                    className={`h-12 w-12 rounded-full border-2 transition-all flex items-center justify-center ${
                      selectedColor === color ? 'border-slate-900 p-1' : 'border-transparent'
                    }`}
                  >
                    <div 
                      className="w-full h-full rounded-full shadow-inner"
                      style={{ backgroundColor: color.toLowerCase() === 'noir' ? '#111' : color.toLowerCase() === 'camel' ? '#c19a6b' : '#eee' }}
                    />
                  </button>
                ))}
              </div>
            </div>
          )}

          {product.sizes && (
            <div className="mb-8">
              <div className="flex justify-between items-center mb-4">
                <h4 className="text-xs font-bold uppercase tracking-widest text-slate-400">Select Size</h4>
                <button className="text-xs font-bold underline underline-offset-4">Size Guide</button>
              </div>
              <div className="flex flex-wrap gap-4">
                {product.sizes.map(size => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={`min-w-[4rem] px-4 py-3 rounded-xl border-2 font-bold transition-all ${
                      selectedSize === size ? 'border-slate-900 bg-slate-900 text-white' : 'border-slate-200 text-slate-500 hover:border-slate-900'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="mt-auto space-y-6">
            <div className="flex items-center space-x-6">
              <div className="flex items-center border-2 border-slate-100 rounded-2xl p-2 bg-slate-50">
                <button onClick={() => setQuantity(q => Math.max(1, q - 1))} className="p-2 text-slate-400 hover:text-slate-900"><Minus size={20} /></button>
                <span className="w-12 text-center font-bold text-lg">{quantity}</span>
                <button onClick={() => setQuantity(q => q + 1)} className="p-2 text-slate-400 hover:text-slate-900"><Plus size={20} /></button>
              </div>
              <button 
                onClick={() => onAddToCart(product, quantity, selectedColor, selectedSize)}
                className="flex-1 bg-slate-900 text-white py-5 rounded-2xl font-bold shadow-xl shadow-slate-200 hover:bg-slate-800 transition-all active:scale-95 flex items-center justify-center space-x-3"
              >
                <Plus size={20} />
                <span>Add to Bag</span>
              </button>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center space-x-3 text-sm font-medium text-slate-600 bg-slate-50 p-4 rounded-2xl">
                <Truck size={20} className="text-slate-900" />
                <span>Free Express Delivery</span>
              </div>
              <div className="flex items-center space-x-3 text-sm font-medium text-slate-600 bg-slate-50 p-4 rounded-2xl">
                <ShieldCheck size={20} className="text-slate-900" />
                <span>2-Year Warranty</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs / Content */}
      <div className="mt-24">
        <div className="flex border-b border-slate-100 mb-12">
          {['description', 'specifications', 'reviews'].map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-8 py-4 text-sm font-bold uppercase tracking-widest transition-all border-b-2 ${
                activeTab === tab ? 'border-slate-900 text-slate-900' : 'border-transparent text-slate-400 hover:text-slate-600'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        <div className="max-w-4xl">
          {activeTab === 'description' && (
            <div className="space-y-6 text-slate-600 leading-relaxed">
              <p className="text-lg text-slate-900 font-medium">Elevate your everyday with the {product.name}.</p>
              <p>{product.description}</p>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-8">
                {['Premium quality materials', 'Ethically manufactured', 'Exclusive limited edition', 'Hand-finished details'].map((f, i) => (
                  <li key={i} className="flex items-center space-x-3">
                    <div className="bg-slate-900 rounded-full p-1 text-white"><Check size={12} /></div>
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
          {activeTab === 'specifications' && (
             <div className="divide-y divide-slate-100">
               {product.specs ? Object.entries(product.specs).map(([key, value]) => (
                 <div key={key} className="flex py-4">
                   <span className="w-1/3 text-sm font-bold text-slate-400 uppercase tracking-widest">{key}</span>
                   <span className="flex-1 text-slate-700">{value}</span>
                 </div>
               )) : (
                 <div className="py-4 text-slate-500">Standard retail specifications apply.</div>
               )}
             </div>
          )}
          {activeTab === 'reviews' && (
            <div className="space-y-12">
              <div className="flex items-center justify-between">
                <h3 className="text-2xl font-bold">What people are saying</h3>
                <button className="px-6 py-3 bg-white border-2 border-slate-900 rounded-full font-bold hover:bg-slate-900 hover:text-white transition-all">Write a review</button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {[
                  { name: "Julian R.", date: "Jan 12, 2024", comment: "Absolutely incredible quality. Exceeded my expectations in every way.", rating: 5 },
                  { name: "Sophia M.", date: "Feb 05, 2024", comment: "The fit is perfect and the material feels luxurious. Shipping was fast too!", rating: 4 }
                ].map((rev, i) => (
                  <div key={i} className="bg-slate-50 p-6 rounded-3xl space-y-4">
                    <div className="flex justify-between items-start">
                      <div className="flex text-amber-400">
                        {[...Array(5)].map((_, j) => <Star key={j} size={14} fill={j < rev.rating ? "currentColor" : "none"} />)}
                      </div>
                      <span className="text-xs text-slate-400 font-bold">{rev.date}</span>
                    </div>
                    <p className="text-slate-700 font-medium italic">"{rev.comment}"</p>
                    <p className="text-sm font-bold text-slate-900">— {rev.name}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
