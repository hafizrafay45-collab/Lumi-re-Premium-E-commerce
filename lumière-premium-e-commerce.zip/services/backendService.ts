
import { CartItem, Order } from '../types';

const DB_NAME = 'LumiereDB';
const DB_VERSION = 2;
const STORES = {
  CART: 'cart',
  ORDERS: 'orders',
  USER: 'user_profile'
};

class BackendEngine {
  private db: IDBDatabase | null = null;

  async init(): Promise<void> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        if (!db.objectStoreNames.contains(STORES.CART)) {
          db.createObjectStore(STORES.CART, { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains(STORES.ORDERS)) {
          db.createObjectStore(STORES.ORDERS, { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains(STORES.USER)) {
          db.createObjectStore(STORES.USER, { keyPath: 'id' });
        }
      };

      request.onsuccess = (event) => {
        this.db = (event.target as IDBOpenDBRequest).result;
        resolve();
      };

      request.onerror = (event) => reject((event.target as IDBOpenDBRequest).error);
    });
  }

  private async getStore(storeName: string, mode: IDBTransactionMode = 'readonly'): Promise<IDBObjectStore> {
    if (!this.db) await this.init();
    const transaction = this.db!.transaction(storeName, mode);
    return transaction.objectStore(storeName);
  }

  // Cart Management
  async getCart(): Promise<CartItem[]> {
    const store = await this.getStore(STORES.CART);
    return new Promise((resolve) => {
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result || []);
    });
  }

  async saveCart(cart: CartItem[]): Promise<void> {
    const store = await this.getStore(STORES.CART, 'readwrite');
    return new Promise((resolve) => {
      const clearRequest = store.clear();
      clearRequest.onsuccess = () => {
        cart.forEach(item => store.add(item));
        resolve();
      };
    });
  }

  // Order Management
  async getOrders(): Promise<Order[]> {
    const store = await this.getStore(STORES.ORDERS);
    return new Promise((resolve) => {
      const request = store.getAll();
      request.onsuccess = () => {
        const orders = request.result || [];
        // Sort by date descending
        resolve(orders.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
      };
    });
  }

  async createOrder(orderData: Omit<Order, 'id' | 'date' | 'status'>): Promise<Order> {
    const store = await this.getStore(STORES.ORDERS, 'readwrite');
    const newOrder: Order = {
      ...orderData,
      id: `LM-${Math.floor(100000 + Math.random() * 900000)}`,
      date: new Date().toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric', 
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      }),
      status: 'Processing',
    };

    return new Promise((resolve) => {
      const request = store.add(newOrder);
      request.onsuccess = async () => {
        await this.saveCart([]); // Transactional: clear cart on order success
        resolve(newOrder);
      };
    });
  }
}

export const backendService = new BackendEngine();
