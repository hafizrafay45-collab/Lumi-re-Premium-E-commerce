
import { GoogleGenAI } from "@google/genai";
import { PRODUCTS } from "../constants";

// The GoogleGenAI instance should be created inside the function to ensure the latest API key is used.
export const getShoppingAdvice = async (userPrompt: string, history: { role: 'user' | 'model', parts: { text: string }[] }[]) => {
  // Initialize AI client directly with process.env.API_KEY as per security and initialization guidelines.
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  try {
    const productContext = JSON.stringify(PRODUCTS.map(p => ({
      name: p.name,
      category: p.category,
      price: p.price,
      description: p.description
    })));

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: [
        ...history,
        { role: 'user', parts: [{ text: userPrompt }] }
      ],
      config: {
        systemInstruction: `You are Lumi, a premium shopping assistant for Lumière. 
        Available products: ${productContext}. 
        Keep responses concise, helpful, and elegant. 
        If a user asks for recommendations, use the products listed above. 
        Don't mention you are an AI. You are a personal concierge.`,
        temperature: 0.7,
      },
    });

    // The text property is a getter, not a method.
    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "I'm sorry, I'm having trouble connecting to my knowledge base right now. How else can I assist you?";
  }
};
