
import React, { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, useLocation, Link } from 'react-router';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Shop from './pages/Shop';
import ProductDetail from './pages/ProductDetail';
import Checkout from './pages/Checkout';
import CartDrawer from './components/CartDrawer';
import GeminiAssistant from './components/GeminiAssistant';
import { Product, CartItem, Order } from './types';
import { backendService } from './services/backendService';

const ScrollToTop = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

const App: React.FC = () => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [orders, setOrders] = useState<Order[]>([]);
  const [isReady, setIsReady] = useState(false);

  // Robust Initialization
  useEffect(() => {
    const initBackend = async () => {
      try {
        await backendService.init();
        const storedCart = await backendService.getCart();
        const storedOrders = await backendService.getOrders();
        setCart(storedCart);
        setOrders(storedOrders);
        setIsReady(true);
      } catch (err) {
        console.error("Critical Backend Failure:", err);
        // Fallback or error UI could go here
        setIsReady(true);
      }
    };
    initBackend();
  }, []);

  // Persistent Synchronization
  useEffect(() => {
    if (isReady) {
      backendService.saveCart(cart);
    }
  }, [cart, isReady]);

  const addToCart = (product: Product, quantity: number = 1, color?: string, size?: string) => {
    setCart(prev => {
      const existing = prev.find(item => 
        item.id === product.id && 
        item.selectedColor === color && 
        item.selectedSize === size
      );
      if (existing) {
        return prev.map(item => 
          item.id === product.id && 
          item.selectedColor === color && 
          item.selectedSize === size
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { ...product, quantity, selectedColor: color, selectedSize: size }];
    });
    setIsCartOpen(true);
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(item => 
      item.id === id ? { ...item, quantity: Math.max(1, item.quantity + delta) } : item
    ));
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  const handleOrderComplete = (order: Order) => {
    setOrders(prev => [order, ...prev]);
    setCart([]);
  };

  if (!isReady) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-white">
        <div className="flex flex-col items-center space-y-6">
          <h1 className="text-4xl font-display font-bold tracking-tighter animate-pulse">LUMIÈRE</h1>
          <div className="w-12 h-1 bg-slate-100 rounded-full overflow-hidden">
            <div className="h-full bg-slate-900 w-1/2 animate-[shimmer_1.5s_infinite]" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <Router>
      <div className="flex flex-col min-h-screen bg-white">
        <ScrollToTop />
        <Navbar 
          cartCount={cart.reduce((acc, i) => acc + i.quantity, 0)} 
          onCartClick={() => setIsCartOpen(true)} 
        />
        
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home onAddToCart={addToCart} />} />
            <Route path="/shop" element={<Shop onAddToCart={addToCart} />} />
            <Route path="/product/:id" element={<ProductDetail onAddToCart={addToCart} />} />
            <Route path="/checkout" element={<Checkout cart={cart} onOrderComplete={handleOrderComplete} />} />
            <Route path="/account" element={
              <div className="max-w-7xl mx-auto px-4 py-24">
                <div className="max-w-4xl mx-auto space-y-12 animate-in fade-in duration-700">
                  <header className="text-center">
                    <h1 className="text-5xl font-display font-bold text-slate-900 mb-4">Your Portfolio</h1>
                    <p className="text-slate-500 italic">Managing your premium lifestyle selections.</p>
                  </header>

                  <section className="space-y-8">
                    <h2 className="text-2xl font-bold border-b border-slate-100 pb-4">Purchase History</h2>
                    {orders.length === 0 ? (
                      <div className="text-center py-24 bg-slate-50 rounded-[3rem] border-2 border-dashed border-slate-200">
                        <p className="text-slate-400 font-medium">No transactions on record.</p>
                        <Link to="/shop" className="text-slate-900 underline underline-offset-8 mt-4 inline-block font-bold hover:text-slate-600">Explore Collection</Link>
                      </div>
                    ) : (
                      <div className="space-y-6">
                        {orders.map(order => (
                          <div key={order.id} className="bg-white border border-slate-100 rounded-[2rem] p-8 shadow-sm hover:shadow-xl hover:shadow-slate-200/50 transition-all duration-500">
                            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-6">
                              <div className="space-y-1">
                                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Order Reference</p>
                                <p className="font-bold text-xl text-slate-900">{order.id}</p>
                              </div>
                              <div className="space-y-1 text-left md:text-center">
                                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Confirmed On</p>
                                <p className="font-semibold text-slate-700">{order.date}</p>
                              </div>
                              <div className="space-y-1 text-left md:text-center">
                                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Status</p>
                                <span className="inline-block bg-slate-900 text-white px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest">{order.status}</span>
                              </div>
                              <div className="space-y-1 text-left md:text-right">
                                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Total Value</p>
                                <p className="font-bold text-xl text-slate-900">${order.total.toFixed(2)}</p>
                              </div>
                            </div>
                            <div className="flex -space-x-4 overflow-hidden pt-4">
                              {order.items.map((item, i) => (
                                <div key={i} className="h-20 w-20 rounded-2xl border-4 border-white overflow-hidden shadow-md">
                                  <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                                </div>
                              ))}
                              {order.items.length > 4 && (
                                <div className="h-20 w-20 rounded-2xl border-4 border-white bg-slate-100 flex items-center justify-center text-slate-500 font-bold text-xs">
                                  +{order.items.length - 4}
                                </div>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </section>
                </div>
              </div>
            } />
          </Routes>
        </main>

        <footer className="bg-slate-950 text-slate-400 py-24">
          <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-12">
            <div className="space-y-6">
              <h3 className="text-white text-3xl font-display font-bold tracking-tighter">LUMIÈRE</h3>
              <p className="text-sm leading-relaxed max-w-xs">
                Crafting a legacy of uncompromising quality and visionary design for the modern connoisseur.
              </p>
            </div>
            
            <div>
              <h4 className="text-white font-bold uppercase tracking-widest text-xs mb-8">Navigation</h4>
              <ul className="space-y-4 text-sm font-medium">
                <li><Link to="/shop?category=Women" className="hover:text-white transition-colors">Women's Collection</Link></li>
                <li><Link to="/shop?category=Men" className="hover:text-white transition-colors">Men's Apparel</Link></li>
                <li><Link to="/shop?category=Electronics" className="hover:text-white transition-colors">Applied Tech</Link></li>
                <li><Link to="/shop?category=Accessories" className="hover:text-white transition-colors">Lifestyle Kit</Link></li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-bold uppercase tracking-widest text-xs mb-8">Customer Care</h4>
              <ul className="space-y-4 text-sm font-medium">
                <li className="hover:text-white transition-colors cursor-pointer">Live Logistics Tracking</li>
                <li className="hover:text-white transition-colors cursor-pointer">Global Exchanges</li>
                <li className="hover:text-white transition-colors cursor-pointer">The Fitting Studio</li>
                <li className="hover:text-white transition-colors cursor-pointer">Concierge Support</li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-bold uppercase tracking-widest text-xs mb-8">Company</h4>
              <ul className="space-y-4 text-sm font-medium">
                <li className="hover:text-white transition-colors cursor-pointer">Sustainability Charter</li>
                <li className="hover:text-white transition-colors cursor-pointer">Press Inquiries</li>
                <li className="hover:text-white transition-colors cursor-pointer">Legal & Privacy</li>
              </ul>
            </div>
          </div>
          <div className="max-w-7xl mx-auto px-4 mt-24 pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6">
            <p className="text-[10px] uppercase tracking-[0.4em] font-bold text-slate-600">LUMIÈRE GROUP S.A. © 2024</p>
            <div className="flex items-center space-x-8 opacity-30 grayscale hover:grayscale-0 hover:opacity-100 transition-all duration-500">
               <img src="https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg" alt="Paypal" className="h-4" />
               <img src="https://upload.wikimedia.org/wikipedia/commons/5/5e/Visa_Inc._logo.svg" alt="Visa" className="h-4" />
               <img src="https://upload.wikimedia.org/wikipedia/commons/2/2a/Mastercard-logo.svg" alt="Mastercard" className="h-6" />
            </div>
          </div>
        </footer>

        <CartDrawer 
          isOpen={isCartOpen} 
          onClose={() => setIsCartOpen(false)} 
          items={cart}
          onUpdateQuantity={updateQuantity}
          onRemove={removeFromCart}
        />
        
        <GeminiAssistant />
      </div>
    </Router>
  );
};

export default App;
