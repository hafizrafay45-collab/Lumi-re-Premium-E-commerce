
import React from 'react';
import { Star, Heart, Plus } from 'lucide-react';
import { Product } from '../types';
// Changed import source to 'react-router' to resolve exported member errors.
import { Link } from 'react-router';

interface ProductCardProps {
  product: Product;
  onAddToCart: (p: Product) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onAddToCart }) => {
  return (
    <div className="group relative flex flex-col bg-white overflow-hidden transition-all hover:shadow-xl hover:shadow-slate-200/50 rounded-2xl">
      <div className="relative aspect-[4/5] overflow-hidden bg-slate-100">
        <img
          src={product.image}
          alt={product.name}
          className="h-full w-full object-cover object-center transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute top-4 right-4 space-y-2 opacity-0 group-hover:opacity-100 transition-opacity translate-x-4 group-hover:translate-x-0 duration-300">
          <button className="p-2 bg-white rounded-full shadow-md hover:bg-slate-50 text-slate-600 transition-colors">
            <Heart size={18} />
          </button>
          <button 
            onClick={() => onAddToCart(product)}
            className="p-2 bg-slate-900 text-white rounded-full shadow-md hover:bg-slate-800 transition-colors"
          >
            <Plus size={18} />
          </button>
        </div>
        {product.isNew && (
          <span className="absolute top-4 left-4 px-3 py-1 bg-white text-[10px] font-bold tracking-widest uppercase text-slate-900 rounded-full shadow-sm">
            NEW
          </span>
        )}
        {product.isSale && (
          <span className="absolute top-4 left-4 px-3 py-1 bg-rose-500 text-[10px] font-bold tracking-widest uppercase text-white rounded-full shadow-sm">
            SALE
          </span>
        )}
      </div>

      <div className="flex flex-1 flex-col p-4">
        <div className="flex justify-between items-start mb-1">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
            {product.category}
          </p>
          <div className="flex items-center space-x-1 text-slate-900 text-xs">
            <Star size={12} fill="currentColor" />
            <span className="font-semibold">{product.rating}</span>
          </div>
        </div>
        <Link to={`/product/${product.id}`} className="hover:underline decoration-slate-300 underline-offset-4">
          <h3 className="text-sm font-semibold text-slate-900 mb-2 truncate">
            {product.name}
          </h3>
        </Link>
        <div className="mt-auto">
          <p className="text-base font-bold text-slate-900">
            ${product.price.toFixed(2)}
          </p>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
