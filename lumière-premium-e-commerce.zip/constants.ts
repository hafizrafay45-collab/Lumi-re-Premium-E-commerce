
import { Product } from './types';

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Silk Drapery Blouse',
    category: 'Women',
    price: 189,
    description: 'Ethically sourced 100% mulberry silk blouse with a fluid silhouette and pearl button detailing.',
    image: 'https://images.unsplash.com/photo-1551163943-3f6a855d1153?auto=format&fit=crop&q=80&w=800',
    rating: 4.8,
    reviews: 124,
    stock: 15,
    colors: ['Cream', 'Noir', 'Champagne'],
    sizes: ['XS', 'S', 'M', 'L'],
    isNew: true
  },
  {
    id: '2',
    name: 'Studio Monitor Headset',
    category: 'Electronics',
    price: 349,
    description: 'Reference-grade wireless headphones with active noise cancellation and 40-hour battery life.',
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&q=80&w=800',
    rating: 4.9,
    reviews: 890,
    stock: 50,
    specs: {
      'Driver': '40mm Neodymium',
      'Battery': 'Up to 40 Hours',
      'Connectivity': 'Bluetooth 5.2'
    }
  },
  {
    id: '3',
    name: 'Cashmere Overcoat',
    category: 'Men',
    price: 599,
    description: 'A timeless classic tailored from Italian cashmere-wool blend. Perfect for winter layering.',
    image: 'https://images.unsplash.com/photo-1539533377285-3c129452b47d?auto=format&fit=crop&q=80&w=800',
    rating: 4.7,
    reviews: 45,
    stock: 8,
    colors: ['Camel', 'Navy', 'Grey'],
    sizes: ['M', 'L', 'XL'],
    isSale: true
  },
  {
    id: '4',
    name: 'Minimalist Leather Watch',
    category: 'Accessories',
    price: 220,
    description: 'Swiss-movement timepiece featuring a clean dial and vegetable-tanned leather strap.',
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=800',
    rating: 4.6,
    reviews: 212,
    stock: 25,
    colors: ['Tan', 'Black']
  },
  {
    id: '5',
    name: 'Smart Home Hub Pro',
    category: 'Electronics',
    price: 129,
    description: 'The central brain for your connected home. Voice activated with premium speakers.',
    image: 'https://images.unsplash.com/photo-1589492477829-5e65395b66cc?auto=format&fit=crop&q=80&w=800',
    rating: 4.5,
    reviews: 1567,
    stock: 100,
    isNew: true
  },
  {
    id: '6',
    name: 'Organic Cotton Tee',
    category: 'Men',
    price: 45,
    description: 'Ultra-soft GOTS certified organic cotton t-shirt with a relaxed fit.',
    image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&q=80&w=800',
    rating: 4.9,
    reviews: 340,
    stock: 200,
    colors: ['White', 'Black', 'Olive'],
    sizes: ['S', 'M', 'L', 'XL']
  },
  {
    id: '7',
    name: 'Tailored Wool Suit',
    category: 'Men',
    price: 850,
    description: 'Full-canvas construction wool suit for a sharp, professional look.',
    image: 'https://images.unsplash.com/photo-1594932224828-b4b059b6f6ee?auto=format&fit=crop&q=80&w=800',
    rating: 4.8,
    reviews: 24,
    stock: 5,
    colors: ['Navy', 'Charcoal'],
    sizes: ['48', '50', '52']
  },
  {
    id: '8',
    name: 'Chelsea Leather Boots',
    category: 'Men',
    price: 280,
    description: 'Handcrafted Italian leather boots with a durable rubber sole.',
    image: 'https://images.unsplash.com/photo-1638247025967-b4e38f68917a?auto=format&fit=crop&q=80&w=800',
    rating: 4.7,
    reviews: 82,
    stock: 12,
    colors: ['Tan', 'Black'],
    sizes: ['41', '42', '43', '44']
  },
  {
    id: '9',
    name: 'Premium Leather Portfolio',
    category: 'Accessories',
    price: 145,
    description: 'Essential for the modern executive. Carry your laptop and documents in style.',
    image: 'https://images.unsplash.com/photo-1621607512214-68297480165e?auto=format&fit=crop&q=80&w=800',
    rating: 4.9,
    reviews: 18,
    stock: 30
  },
  {
    id: '10',
    name: 'Linen Summer Dress',
    category: 'Women',
    price: 120,
    description: 'Breathable European linen dress with a flattering wrap silhouette.',
    image: 'https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?auto=format&fit=crop&q=80&w=800',
    rating: 4.6,
    reviews: 56,
    stock: 20,
    colors: ['Sage', 'White', 'Oat'],
    sizes: ['S', 'M', 'L']
  },
  {
    id: '11',
    name: 'Noise Cancelling Buds',
    category: 'Electronics',
    price: 199,
    description: 'Ultra-portable audio with industry-leading sound isolation technology.',
    image: 'https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&q=80&w=800',
    rating: 4.8,
    reviews: 432,
    stock: 75
  },
  {
    id: '12',
    name: 'Designer Silk Scarf',
    category: 'Accessories',
    price: 95,
    description: 'Hand-rolled edges and exclusive botanical print on pure silk twill.',
    image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&q=80&w=800',
    rating: 4.7,
    reviews: 12,
    stock: 10
  },
  {
    id: '13',
    name: 'Canvas Tech Tote',
    category: 'Accessories',
    price: 85,
    description: 'Minimalist tote with padded compartments for your laptop and gadgets.',
    image: 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&q=80&w=800',
    rating: 4.5,
    reviews: 29,
    stock: 40
  },
  {
    id: '14',
    name: 'Satin Evening Gown',
    category: 'Women',
    price: 450,
    description: 'An elegant floor-length gown crafted from heavyweight liquid satin.',
    image: 'https://images.unsplash.com/photo-1566174053879-31528523f8ae?auto=format&fit=crop&q=80&w=800',
    rating: 4.9,
    reviews: 15,
    stock: 5,
    isNew: true
  },
  {
    id: '15',
    name: 'Performance Chinos',
    category: 'Men',
    price: 135,
    description: 'Four-way stretch chinos that transition perfectly from office to evening.',
    image: 'https://images.unsplash.com/photo-1473963456455-dc046890f948?auto=format&fit=crop&q=80&w=800',
    rating: 4.7,
    reviews: 88,
    stock: 60
  }
];

export const CATEGORIES = ['All', 'Women', 'Men', 'Electronics', 'Accessories'];
